# CSC1015F Assignment 1 rabbit.py
# Name: Yifei Yu
# Date: 8th March 2018
# Question Number 1

print("(\\\\               (\/)")
print("( '')    (\_/)   (.. )   //)")
print("""O(")(") (\\'.'/) (")(")O (" )""")
print("""        (")_(")        ()()o""")

