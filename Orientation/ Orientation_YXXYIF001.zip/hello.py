# My very first program to display Hello World on screen
# Name:Yifei Yu
# Student Number:YXXYIF001
# Date:28th February 2018
print ("Hello World")
